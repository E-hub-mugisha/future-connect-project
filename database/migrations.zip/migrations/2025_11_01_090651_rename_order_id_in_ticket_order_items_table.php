<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('ticket_order_items', function (Blueprint $table) {
            $table->renameColumn('order_id', 'ticket_order_id');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('ticket_order_items', function (Blueprint $table) {
            $table->renameColumn('ticket_order_id', 'order_id');
        });
    }
};
